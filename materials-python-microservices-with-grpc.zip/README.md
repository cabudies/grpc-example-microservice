# Running the Example

1. Install Docker if you haven't already.
2. Run `./build_and_run.sh`.
